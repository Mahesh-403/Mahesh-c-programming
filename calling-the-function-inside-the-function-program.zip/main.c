/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void firstFunction();
void secondFunction();//function declaration

int main()
{
    firstFunction();
    secondFunction();

    return 0;
}
void firstFunction(){//first function difinition
    printf("This is my first Function data ....\n");
    secondFunction();
}
void secondFunction(){//secondFunction difinition
    printf("This is my seconcd function data.....\n");
}