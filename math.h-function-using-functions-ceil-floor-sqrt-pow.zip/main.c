/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <math.h>

int main()
{
    
    printf("% 2.f\n",sqrt(25));
    printf("% 2.f\n",ceil(1.9));
    printf("% 2.f\n",floor(1.9));
    printf("% 2.f",pow(2,6));
    return 0;
}