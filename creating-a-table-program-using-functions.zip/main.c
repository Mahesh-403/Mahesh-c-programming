/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void add(){
int a,b,sum;
    
    printf("Enter the a and b value :");
    scanf("%d %d",&a,&b);
    sum=a+b;
printf("sum is %d\n",sum);
}
void Table(){
    int i,t,n;
    printf("Enter the table nuber :");
    scanf("%d",&n);
    for(i=1;i<=20;i++){
    t=n*i;
    printf("%d*%d = %d\n ",n,i,t);
    }
}
int main()
{
    add();
   Table();
    return 0;
}