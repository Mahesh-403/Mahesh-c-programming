/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
int myNumbers(int x,int y);// this is the function declaration

int main()
{
   
    
    int result=myNumbers(5,6);//this is the calling function
    printf("the result of myNumbers is %d",result);
    
    return 0;
}
int myNumbers(int x, int y){//this is the function definition
    
    return x+y;
}