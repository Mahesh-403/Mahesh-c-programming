/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void greetMorning(){
    printf("Good morning :\n");
}
void greetEveing(){
    printf("Good Eveingi :\n");
}
void greet(void (*func)()){
func ();
}
int main()
{
    greet(greetMorning);
    greet(greetEveing);

    return 0;
}