/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void countdown(int n);
int main()
{
    countdown(5);
        
    return 0;
}
void countdown(int n){
    if(n>0){
        printf("%d\n",n);
      countdown (n-1);
    }
}